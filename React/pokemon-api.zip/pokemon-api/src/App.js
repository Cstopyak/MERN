import Api from './Components/Api';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import DisplayApi from './Components/DisplayApi';

function App() {
  return (
    <div className="App">
      <Api/>

      <div>
       
      </div>
    </div>
  );
}

export default App;

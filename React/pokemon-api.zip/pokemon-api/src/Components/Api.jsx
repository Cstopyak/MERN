import React, { useEffect, useState } from 'react';
import axios from 'axios';
import DisplayApi from './DisplayApi';
const Api = () => {
    const [ Pokemon, setPokemon] = useState([])

    // const OnChangeHandler = e =>{
    //     setPokemon([...Pokemon, [e.target.name]: e.target.value])
    // }

    const SubmitHandler = e => {
        // e.preventDefault();
        axios.get("https://pokeapi.co/api/v2/pokemon?limit=1000")
        .then(response=> {
            console.log(response.data)
            setPokemon(response.data.results)
            
        })
    }

    //version 1 (basic fetch)
    // fetch("https://pokeapi.co/api/v2/pokemon")
    // .then(response => {
    //     return response.json();
    // }).then(response =>{
    //     console.log(response);
    // }).catch(err=>{
    //     console.log(err);
    // })

    //version 2 (intro use effect)

    // useEffect(() =>{
    //     fetch("https://pokeapi.co/api/v2/pokemon")
    //     .then(response => response.json())
    //     .then(response => console.log(response))
    // }, [])


    // const [Submit, setSubmit] = useState(false)
    // //version 3 axios
    // useEffect(() =>{
    //     axios.get("https://pokeapi.co/api/v2/pokemon")
    //     .then(response => console.log(response))
    //     .then(response=>{setSubmit(response)})
    // }, [Submit])

    // const OnSubmit = e =>{
    //     Submit?
    //     setSubmit(false):
    //     setSubmit(true)
    // }
    


    return (
        <>
            <h1>Hello!</h1>
            <p> Welcome to the Pokemon Api, press fetch to catch them all!</p>
            <input onClick= {SubmitHandler} value="Fetch!" className="btn btn-primary" />
            <DisplayApi Pokemon={Pokemon}/>

        </>
    )
}

export default Api;
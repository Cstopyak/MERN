import React from 'react';

const DisplayApi = props => {
    const { Pokemon } = props
    console.log(Pokemon);
    return(
        <>
        {
            Pokemon.map((onePokemon, x) =>(
                <h3 key= {x}> {onePokemon.name}</h3>
            ))
        }
        </>
    )
}



export default DisplayApi;
import React from 'react';
import { Link } from '@reach/router';


const Home = (props) => {
    return (
        <div>
        Welcome!
        <Link to = "/Home">Home</Link>
        </div>
    )

}

export default Home;
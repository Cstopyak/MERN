import React from 'react';
import { Link } from '@reach/router';


const Hello = (props) => {
    return (
        <div>
        Hello!
        
        </div>
    )

}

export default Hello;
import React from 'react';
import { Link } from '@reach/router';


const HelloColor = (props) => {
    return (
        <div class="divvy">
        <h1>Hello!</h1>
        
        </div>
    )

}

export default HelloColor;
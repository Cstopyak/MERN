import React from 'react';
import { Link } from '@reach/router';


const Four = (props) => {
    return (
        <div>
        The Number is: 4
        
        </div>
    )

}

export default Four;
import React from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Router } from '@reach/router';
import People from './components/People';
import Planets from './components/Planets';
import StarWarsForm from './components/StarWarsForm';


function App() {
  return (

    <div className="App container-fluid">
      

      <h1> The force!</h1>
      <StarWarsForm/>
      
      <Router>
        <People path="people/:id" />
        <Planets path="planets/:id"/>
        
      </Router>
    </div>
  );
}

export default App;

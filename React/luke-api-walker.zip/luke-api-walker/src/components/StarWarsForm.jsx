import React, { useState } from 'react';
import { navigate } from '@reach/router';

const StarWarsForm = props => {
    const [ num, setNum] = useState(1)
    const [resource, setResource,] = useState("")
    

    const SubmitHandler = e => {
        e.preventDefault();
        navigate(`/${resource}/${num}`)
    }

    return (
        <form onSubmit={SubmitHandler}>
        {/* <div className="form-group col-sm-4"> */}
            < label htmlFor="id"> Pick a number</label>
            <select name="resource" onChange={ e => setResource(e.target.value) }>
                <option value="people">People</option>
                <option value="planets">Planets</option>
            </select>
            <input type="number" name="number" className="form-control" onChange={ e => setNum(e.target.value) }/>
        {/* </div> */}
        <button type="submit" className="btn btn-primary"> Search</button>
    </form>
    );
}
export default StarWarsForm;
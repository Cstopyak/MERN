import axios from 'axios';
import React, { useEffect, useState } from 'react';



const People = props => {
    const [people, setPeople] = useState(null)

    useEffect(() => {
        axios.get(`https://swapi.dev/api/people/${props.id}`)
            .then(response => {
                setPeople(response.data)
                console.log(response.data)
            })
            .catch(err => console.log(err))
    }, [props])

    



    return (
        <>
        {
            people ? <> 
                <p>You are looking at the people with id </p>
                <h1> {people.name}</h1>
                <h3> Height: {people.height} </h3>
                <h3> Mass: {people.mass} </h3>
                <h3> Hair Color: {people.hair_color}</h3>
                <h3> Skin Color: {people.skin_color} </h3>
            </> : ""
        }
        
        </>
    );
}
export default People;
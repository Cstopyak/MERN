import React, { Component } from 'react';

class PersonCardComp extends Component {
    render() {
        return (
            <div>
                <h3> Name:{this.props.name}</h3>
                <p> Age:{this.props.age}</p>
                <p> Hair:{this.props.hair}</p>
            </div>
        );
    }
}

export default PersonCardComp;
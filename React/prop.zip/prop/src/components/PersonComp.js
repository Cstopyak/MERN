import React, { Component } from 'react';

class PersonComp extends Component {
    render(){
        return(
            <div>
                <h1> Hello Component</h1>
            </div>
        );
    }

}


export default PersonComp;
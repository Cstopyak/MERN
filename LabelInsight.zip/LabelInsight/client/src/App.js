import API from './components/Api';
import Form from './components/Form';
import UpdatePhoto from './views/UpdatePhoto';
import Example from './components/Example';
import DisplayApi from './components/DisplayApi';
import PhotoApi from './components/PhotoApi';
import './App.css';
import { Router } from '@reach/router';
import 'bootstrap/dist/css/bootstrap.min.css';
function App() {
  return (
    <div className="App">
      <PhotoApi/>
      
      
    </div>
  );
}

export default App;

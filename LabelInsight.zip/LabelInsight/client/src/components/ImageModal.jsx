import React, { Component } from 'react';
import Modal from 'react-bootstrap/Modal';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';


class ImageModal extends Component {
    constructor(props) {
        super(props);
        this.state = {
        photo: {},
        descTextBox: ''
        };
    }

    componentWillReceiveProps(nextProps) {
        const storagePhotos = JSON.parse(localStorage.getItem('photos'));
        if(storagePhotos) {
            const existing = storagePhotos.filter(photo => {return photo.id === nextProps.photo.id});
            if(existing.length) {
            this.setState({photo: existing[0]});
                } 
                else 
                {
                this.setState({
                    photo: nextProps.photo});
                }
                } 
                else 
                {
                this.setState({
                    photo: nextProps.photo}); 
                }
        }

        onEditHandler = () => {
            this.setState({ descTextBox: true });
        }

        handleOnChange = (e) => {
            const { photo } = this.state;
            photo['description'] = e.target.value;
            this.setState({ description: photo });
        }

        onSubmitHandler = (e) => {
            e.preventDefault();
            const { photo } = this.state;
            const storagePhotos = JSON.parse(localStorage.getItem('photos'));

            if(storagePhotos) {
            const index = storagePhotos.findIndex(local => local.id === photo.id);
            if(index >= 0) {
                storagePhotos[index] = photo;
                localStorage.setItem('photos', JSON.stringify(storagePhotos));
            } else {
                storagePhotos.push(photo);
                localStorage.setItem('photos', JSON.stringify(storagePhotos));
            }
            } else {
            localStorage.setItem('photos', JSON.stringify([photo]));
            }
            this.setState({ descTextBox: false });
        }

        render() {
            const { descTextBox, photo } = this.state;
            let textArea;

            if(descTextBox) {
            textArea = (
                <Form onSubmit={e => this.onSubmitHandler(e)}>
                <Form.Group controlId="photoGroup">
                    <Form.Label>Edit Description: </Form.Label>
                    <Form.Control type="text" defaultValue={photo.description} onChange={this.handleOnChange}/> 
                </Form.Group>
                <Button variant="primary" type="submit">Submit</Button>
                </Form>
            );
            }

        const descriptionBox = descTextBox ? {display: 'none'} : {display: 'block'};

    return (
        <div className="container-fluid">
        <Modal
            {...this.props}
            size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            centered >
            <Modal.Header closeButton>
                <Modal.Title id="contained-modal-title-vcenter">{ photo.title }</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <div className="container-fluid">
                <img src={ photo.url } alt={ photo.title }/>
                </div>
                {textArea}
                <div input={descriptionBox}>
                <h3 className="description">Description: </h3>
                <p>{ 
                photo.description ? photo.description : 'Please add a descripion' }</p>
                <Button variant="danger" onClick={this.onEditHandler}>Edit</Button>
                </div>  
            </Modal.Body>
            <Modal.Footer>
                <Button variant="primary" onClick={this.props.onHide}>Close</Button>
            </Modal.Footer>
            </Modal>
            </div>
        );
    }
}

export default ImageModal;

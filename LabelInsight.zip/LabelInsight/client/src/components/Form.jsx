import React, { useState, useEffect } from "react";
const Form = (props) => {
  
  return (
    <div>
      <h1> this is my form component</h1>
      <form onSubmit={e => this.handleSubmit(e)}>
        <div className="row">
          <div className="col-sm-2"></div>
          <div className="col-sm-8">
            <div className="form-group">
              <label htmlFor="description"> description</label>
              <input type="text" name="description" className="form-control" />
            </div>

            <input type="submit" value="Submit" className="btn btn-primary" />
          </div>
        </div>
      </form>
    </div>
  );
};

export default Form;

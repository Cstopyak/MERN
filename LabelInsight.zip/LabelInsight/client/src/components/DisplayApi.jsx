import axios from "axios";
import { Link } from '@reach/router';
import React, { useEffect, useState } from 'react';
const DisplayApi = (props) => {
    const [error, setError] = useState(null);
    const [isLoaded, setIsLoaded] = useState(false);
    const [items, setItems] = useState([]);
    const [photo, setPhoto] = useState([]);
    // Note: the empty deps array [] means
    // this useEffect will run once
    // similar to componentDidMount()
    useEffect(() => {
      axios
        .get(`https:jsonplaceholder.typicode.com/photos`)
        .then((response) => {
        console.log(response);
        setPhoto(response.data.slice(0, 25));
        })
        .catch((err) => console.log(err));
    }, [props]);
  
    if (error) {
      return <div>Error: {error.message}</div>;
    } else if (!isLoaded) {
      return <div>Loading...</div>;
    } else {
      return (
        <>
            
                
                
                {
                    photo.map((onePhoto, index) =>{
                        return <div className="card"  style={{width: "22rem",
                    display:"inline-block", padding:"10px"}}> <Link to={"/photos/" + onePhoto.thumbnailUrl}></Link>
                        {onePhoto.thumbnailUrl}</div>
                    })
                }
                
                
                
            
            </>
      );
    }
  }
export default DisplayApi;
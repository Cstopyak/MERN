import React, { Component } from "react";

import ImageModal from "./ImageModal";

    class PhotoApi extends Component {
    constructor(props) {
        super(props);
        this.state = {
            photos: [],
            onSelect: {},
            pictureModal: false,
        };
        }
    componentDidMount() {
    fetch("https://jsonplaceholder.typicode.com/photos")
        .then((res) => res.json())
        .then((data) => this.setState({ photos: data.slice(0, 25) }));
    }

    onClick = (photo) => {
    this.state = this.setState({ pictureModal: true, onSelect: photo });
    };

    ModalChangeHandler = () => {
    this.state = this.setState({pictureModal: false, });
    };

    render() {
        const { photos, onSelect, pictureModal } = this.state;
        let images;
        if (photos) {
        images = photos.map((photo, index) => {
            return (
                
            <div className="card" key={photo.id} style={{width: "150px"}}onClick={() => this.onClick(photo)}><img                
                src={photo.thumbnailUrl} alt="photoimage"
                />
            
            </div>
            );
        });
        }

        return (
            <div className="card"  > 
            {images } 
            <ImageModal show={pictureModal} photo={onSelect} onHide={this.ModalChangeHandler} />{" "}
            </div>
        );
    }
}

export default PhotoApi;

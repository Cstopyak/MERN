import React, { useEffect, useState } from "react";
import axios from "axios";
import '../css/Api.css';
import { Link, navigate } from '@reach/router';


const Api = props => {
const [photo, setPhoto] = useState([]);
const [id, setId] = useState(1);
  // (using axios)
    useEffect(() => {
    axios
        .get(`https://jsonplaceholder.typicode.com/photos/`)
        .then((response) => {
        console.log(response);
        setPhoto(response.data.slice(0, 25));
        })
        .catch((err) => console.log(err));
    }, [props]);

    const handleClick = e =>{
        e.preventDefault();
        navigate(`/${props._id}`)
        console.log('clicked on pic')
    }
    

    return (
            <>
            
                
                
                {
                    photo.map((onePhoto, index) =>{
                        return (<div className="card"  style={{width: "22rem",
                    display:"inline-block", padding:"10px"}} onClick={handleClick}> <Link to={onePhoto.thumbnailUrl}>{onePhoto.thumbnailUrl}</Link>
                        </div>)
                    })
                }
                
                
                
            
            </>

    // <div className="Container">
        
    //     {photo.map((onePhoto, index) => (
    //         <div key={index}>
    //         <hr />
    //         <div className="Container-box">
    //         <img className="image"  src={onePhoto.thumbnailUrl} button  onClick={() => onePhoto.thumbnailUrl}/>
    //         {/* <h5>{onePhoto.title}</h5>
    //         <p>{onePhoto.id}</p> */}
            
    //         </div>
    //     </div>
    //     ))}
    // </div>
    );
};

export default Api;

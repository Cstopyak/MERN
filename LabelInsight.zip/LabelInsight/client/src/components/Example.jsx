import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from '@reach/router';
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import Form from "react-bootstrap/Form";
function Example(props) {
  const [show, setShow] = useState(false);
  const [photo, setPhoto] = useState([]);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  useEffect(() => {
    axios
      .get(`https:jsonplaceholder.typicode.com/photos`)
      .then((response) => {
        console.log(response);
        setPhoto(response.data.slice(0, 25));
      })
      .catch((err) => console.log(err));
  }, [props]);

  const handleClick = (photo) => {
    console.log("clicked on pic");
  };
  return (
    <>
      {photo.map((onePhoto, index) => {
        return (
          <div
            className="card"
            style={{ width: "22rem", display: "inline-block", padding: "10px" }}
          ><Button variant="primary" onClick={handleShow}>
        {onePhoto.thumbnailUrl}
      </Button><Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Modal heading</Modal.Title>
        </Modal.Header>
        <Modal.Body>Woohoo, you're reading this text in a modal!</Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleClose}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
            
            
          </div>
        );
      })}
      

      
    </>
  );
}

export default Example;

// const ninja = require("./ninja.js");

// var Seto = new Ninja("Seto")

// console.log(Seto.name);

// const ninja1 = new Ninja("Hyabusa");
// ninja1.sayName();
// ninja1.showStats();